CREATE DATABASE IF NOT EXISTS universidad;
USE universidad;

CREATE TABLE IF NOT EXISTS estudiantes(
num_matrícula INT UNIQUE PRIMARY KEY,
Nombre_estudiante VARCHAR (50) NOT NULL,
Correo VARCHAR(100)
);

CREATE TABLE IF NOT EXISTS curso(
código_curso INT UNIQUE PRIMARY KEY,
Nom_curso VARCHAR (50) NOT NULL,
Num_crédito VARCHAR (50)
);

CREATE TABLE IF NOT EXISTS profesores(
código_profesor INT UNIQUE PRIMARY KEY,
Nombre VARCHAR (50) NOT NULL,
Especialidad VARCHAR(50) NOT NULL
);
