CREATE DATABASE IF NOT EXISTS biblioteca;
USE biblioteca;

CREATE TABLE IF NOT EXISTS Usuarios(
Num_usuario INT UNIQUE PRIMARY KEY,
Nombre_usuario VARCHAR(50) NOT NULL,
dirrecion VARCHAR (100) 
);

CREATE TABLE IF NOT EXISTS libros(
Código_libro INT UNIQUE PRIMARY KEY,
Título VARCHAR (50) NOT NULL,
Autor VARCHAR(50) NOT NULL,
Año_publicidad DATE NOT NULL
);

CREATE TABLE IF NOT EXISTS prestamo(
Id_prestamo INT UNIQUE PRIMARY KEY,
Libros_prestados VARCHAR(50) NOT NULL,
Fecha_prestamo DATE NOT NULL,
Fecha_entrega DATE NOT NULL,

CONSTRAINT FK_prestamo_usuario FOREIGN KEY (Num_usuario) REFERENCES Usuarios (Num_usuario),
CONSTRAINT FK_prestamo_libro FOREIGN KEY (Código_libro) REFERENCES prestamo(Código_libro)
);



